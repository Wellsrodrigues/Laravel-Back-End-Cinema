<?php

namespace App\Http\Controllers;

use App\Models\Ingresso;
use App\Models\Sessao;
use Exception;
use Illuminate\Http\Request;

class IngressoController extends Controller
{

    public function index()
    {
        $ingresso = Ingresso::all();
        return view('ingresso.select', ['ingresso' => $ingresso]);
    }

    public function create()
    {
        $sessao = Sessao::all();
        return view('ingresso.create', ['sessao' => $sessao]);
    }

    public function store(Request $request)
    {
        try {
            $total = ($request->qtd * $request->preco);

            $ingresso = new Ingresso;

            $ingresso->cpfCliente = $request->cpfCliente;
            $ingresso->tipo = $request->tipo;
            $ingresso->preco = $request->preco;
            $ingresso->poltrona = $request->poltrona;
            $ingresso->qtd = $request->qtd;
            $ingresso->total = $total;
            $ingresso->sessaos_id = $request->sessaos_id;

            $ingresso->save();
            return redirect('/ingresso/select')->with('msg', "1");
        }catch(Exception $ex){
            return redirect('/ingresso/create')->with('msg', "error");
        }
    }

    public function show($id)
    {
        $ingresso = Ingresso::findOrFail($id);
        return view('', ['ingresso' => $ingresso]);
    }

    public function edit($id)
    {
        $ingresso = Ingresso::findOrFail($id);
        return view('ingresso.edit', ['ingresso' => $ingresso]);
    }

    public function update(Request $request)
    {
        $data = $request->all();

        $data['total'] = $data['qtd'] * $data['preco'];

        Ingresso::findOrFail($request->id)->update($data);
        return redirect('/ingresso/select')->with('msg', "2");;
    }

    public function destroy($id)
    {
        Ingresso::findOrFail($id)->delete();
        return redirect('/ingresso/select')->with('msg', "3");;
    }

    
    public function relatory(){
        $ingresso = Ingresso::all();
        return view('ingresso.relatorio', ['ingresso' => $ingresso]);
    }
}