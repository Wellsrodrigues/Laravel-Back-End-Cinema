<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Filme;
use Exception;
use SebastianBergmann\CodeUnit\FunctionUnit;

class FilmeController extends Controller
{

    public function index(){
        $filme = Filme::all();
        return view('filme.select', ['filme' => $filme]);
    }

    public function create (){
        return view('filme.create');
    }

    public function store(Request $request){
       try{
            $filme = new Filme;

            $filme->titulo = $request->titulo;
            $filme->duracao = $request->duracao;
            $filme->ano = $request->ano;
            $filme->classificacao = $request->classificacao;
            $filme->genero = $request->genero;
            $filme->diretor = $request->diretor;
            $filme->banner = $request->banner;
            $filme->sinopse = $request->sinopse;
            $filme->audio = $request->audio;

            $filme->save();
            return redirect('/filme/select')->with('msg', "1");
       }catch(Exception $ex){
            return redirect('/filme/create')->with('msg', "error");
       }
        
    }

    public function show($id){
        $filme = Filme::findOrFail($id);
        return view('filme.more', ['filme' => $filme]);
    }

    public function edit($id){
        $filme = Filme::findOrFail($id);
        return view('filme.edit', ['filme' => $filme]);
    }

    public function update(Request $request){
        Filme::findOrFail($request->id)->update($request->all());
        return redirect('/filme/select')->with('msg', "2");
    }

    public function destroy($id){
        Filme::findOrFail($id)->delete();
        return redirect('/filme/select')->with('msg', "3");
    }
}
