<?php

namespace App\Http\Controllers;

use App\Models\Filme;
use App\Models\Sessao;
use Illuminate\Http\Request;
use Exception;
class SessaoController extends Controller
{
    
    public function index(){
        $sessao = Sessao::all();
        $filme = Filme::all();
        
        return view('sessao.select', ['sessao' => $sessao, 'filme' => $filme]);
    }

    public function create (){
        $filme = Filme::all();
        return view('sessao.create', ['filme' => $filme]);
    }

    public function store(Request $request){
        try {
            $sessao = new Sessao;

            $sessao->dataSessao = $request->dataSessao;
            $sessao->horario = $request->horario;
            $sessao->tipo = $request->tipo;
            $sessao->sala = $request->sala;
            $sessao->qtdLugares = $request->qtdLugares;
            $sessao->filmes_id = $request->filmes_id;

            $sessao->save();
            return redirect('/sessao/select')->with('msg', "1");
        }catch(Exception $ex){
            return redirect('/sessao/create')->with('msg', "error");
        }
    }

    public function show($id){
        $sessao = Sessao::findOrFail($id);
        return view('', ['sessao' => $sessao]);
    }

    public function edit($id){
        $filme = Filme::all();
        $sessao = Sessao::findOrFail($id);
        return view('sessao.edit', ['sessao' => $sessao, 'filme' => $filme]);
    }

    public function update(Request $request){
        Sessao::findOrFail($request->id)->update($request->all());
        return redirect('/sessao/select')->with('msg', "2");;
    }

    public function destroy($id){
        Sessao::findOrFail($id)->delete();
        return redirect('/sessao/select')->with('msg', "3");;
    }
}
