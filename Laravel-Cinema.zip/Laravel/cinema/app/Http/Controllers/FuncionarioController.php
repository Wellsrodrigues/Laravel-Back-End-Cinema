<?php

namespace App\Http\Controllers;

use App\Models\Cinema;
use App\Models\Funcionario;
use Exception;
use Illuminate\Http\Request;

class FuncionarioController extends Controller
{
    public function index(){
        $funcionario = Funcionario::all();
        $cinema = Cinema::all();

        return view('funcionario.select', ['funcionario' => $funcionario, 'cinema' => $cinema]);
    }

    public function create (){
        $cinema = Cinema::all();
        return view('funcionario.create', ['cinema' => $cinema]);
    }

    public function store(Request $request){
       
        try{
            $funcionario = new Funcionario;

            $funcionario->nome = $request->nome;
            $funcionario->cpf = $request->cpf;
            $funcionario->cargo = $request->cargo;
            $funcionario->salario = $request->salario;
            $funcionario->endereco = $request->endereco;
            $funcionario->telefone = $request->telefone;
            $funcionario->cinemas_id = $request->cinemas_id;
    
            $funcionario->save();
            return redirect('/funcionario/select')->with('msg', "1");
        }catch(Exception $ex){
            return redirect('/funcionario/create')->with('msg', "error");
        }
    }

    public function show($id){
        $funcionario = Funcionario::findOrFail($id);
        return view('funcionario.more', ['funcionario' => $funcionario]);
    }

    public function edit($id){
        $cinema = Cinema::all();
        $funcionario = Funcionario::findOrFail($id);

        return view('funcionario.edit', ['funcionario' => $funcionario, 'cinema' => $cinema]);
    }

    public function update(Request $request){
        Funcionario::findOrFail($request->id)->update($request->all());
        return redirect('/funcionario/select')->with('msg', "2");;
    }

    public function destroy($id){
        Funcionario::findOrFail($id)->delete();
        return redirect('/funcionario/select')->with('msg', "3");
    }
}
