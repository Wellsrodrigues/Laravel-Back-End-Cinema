<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cinema extends Model
{
    use HasFactory;

    protected $guarded = [];
    
    public function funcionarios(){
        return $this->hasMany('App\Models\Funcionario');
    }

    public function filmes(){
        return $this->belongsToMany('App\Models\Filme');
    }
}
