<?php

use App\Http\Controllers\FilmeController;
use App\Http\Controllers\FuncionarioController;
use App\Http\Controllers\IngressoController;
use App\Http\Controllers\SessaoController;
use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});

Route::get('/filme/create', [FilmeController::class, 'create']);
Route::get('/filme/select', [FilmeController::class, 'index']);
Route::get('/filme/more/{id}', [FilmeController::class, 'show']);
Route::post('/filme', [FilmeController::class, 'store']);
Route::get('/filme/edit/{id}', [FilmeController::class, 'edit']);
Route::put('/filme/update/{id}', [FilmeController::class, 'update']);
Route::delete('/filme/{id}', [FilmeController::class, 'destroy']);


Route::get('/sessao/create', [SessaoController::class, 'create']);
Route::get('/sessao/select', [SessaoController::class, 'index']);
Route::post('/sessao', [SessaoController::class, 'store']);
Route::get('/sessao/edit/{id}', [SessaoController::class, 'edit']);
Route::put('/sessao/update/{id}', [SessaoController::class, 'update']);
Route::delete('/sessao/{id}', [SessaoController::class, 'destroy']);


Route::get('/funcionario/create', [FuncionarioController::class, 'create']);
Route::get('/funcionario/select', [FuncionarioController::class, 'index']);
Route::post('/funcionario', [FuncionarioController::class, 'store']);
Route::get('/funcionario/edit/{id}', [FuncionarioController::class, 'edit']);
Route::put('/funcionario/update/{id}', [FuncionarioController::class, 'update']);
Route::delete('/funcionario/{id}', [FuncionarioController::class, 'destroy']);


Route::get('/ingresso/create', [IngressoController::class, 'create']);
Route::get('/ingresso/select', [IngressoController::class, 'index']);
Route::post('/ingresso', [IngressoController::class, 'store']);
Route::get('/ingresso/edit/{id}', [IngressoController::class, 'edit']);
Route::put('/ingresso/update/{id}', [IngressoController::class, 'update']);
Route::delete('/ingresso/{id}', [IngressoController::class, 'destroy']);
Route::get('/relatorio', [IngressoController::class, 'relatory']);

