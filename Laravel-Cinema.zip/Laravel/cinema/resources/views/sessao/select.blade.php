@extends('layout.main')

@section('title', 'Sessão')

@section('content')

<div class="container">
        <br>
        <h2>Sessões de Filmes</h2>
        <a class="btn btn-primary" href="/sessao/create" role="button">Nova Sessão</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Data</th>
                    <th>Horário</th>
                    <th>Tipo</th>
                    <th>Sala</th>
                    <th>Assentos</th>
                    <th>Filme</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
            @foreach($sessao as $session)
            <tr>
                <td>{{ $session->id }}</td>
                <td>{{ date('d/m/Y', strtotime ($session->dataSessao))}}</td>
                <td>{{ $session->horario }}</td>
                <td>{{ $session->tipo }}</td>
                <td>{{ $session->sala }}</td>
                <td>{{ $session->qtdLugares }}</td>
                <td>
                    @foreach($filme as $movie)
                        @if($session->filmes_id == $movie->id)
                            {{ $movie->titulo }} 
                        @endif
                    @endforeach
                </td>
                <td>
                    <a href="/sessao/edit/{{ $session->id }}" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <form action="/sessao/{{ $session->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                    </form>
                </td>
            </tr>
            @endforeach
            </tbody>
        </table>
    </div>

@endsection