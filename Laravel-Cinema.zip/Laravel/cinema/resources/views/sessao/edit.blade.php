@extends('layout.main')

@section('title', 'Sessão')

@section('content')
    <br><br>
    <h2>Atualizar dados da Sessão</h2>
    <br><br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/sessao/update/{{ $sessao->id}}">
        @csrf
            @method('PUT')
                <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Data:</strong></label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" value="{{$sessao->dataSessao}}" name="dataSessao" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Horário:</strong></label>
                    <div class="col-sm-10">
                        <input type="time" class="form-control" value="{{ $sessao->horario}}" name="horario" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Tipo:</strong></label>
                    <select class="form-select" name="tipo">
                        <option value="2D" {{ $sessao->tipo == "2D" ? "selected='selected'" : ""}}>2D</option>
                        <option value="3D" {{ $sessao->tipo == "3D" ? "selected='selected'" : ""}}>3D</option>
                        <option value="IMAX" {{ $sessao->tipo == "IMAX" ? "selected='selected'" : ""}}>IMAX</option>
                    </select>
                </div>
            </div>
            <div class="group1">
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Qtd Lugares:</strong></label>
                    <select class="form-select" name="qtdLugares">
                        <option value="30" {{ $sessao->qtdLugares == "30" ? "selected='selected'" : ""}}>30 Assentos</option>
                        <option value="45" {{ $sessao->qtdLugares == "45" ? "selected='selected'" : ""}}>45 Assentos</option>
                        <option value="60" {{ $sessao->qtdLugares == "60" ? "selected='selected'" : ""}}>60 Assentos</option>
                        <option value="100" {{ $sessao->qtdLugares == "100" ? "selected='selected'" : ""}}>100 Assentos</option>
                    </select>
                </div>
                <div class="col-5">
                    <label class="col-sm-0 col-form label"><strong>Filme:</strong></label>

                    <select class="form-select" name="filmes_id">
                        @foreach( $filme as $cine)
                            <option value="{{ $sessao->filmes_id}}" {{ $sessao->filmes_id == $cine->id ? "selected='selected'" : ""}} >{{ $cine->titulo}}</option>
                        @endforeach
                     </select>

                </div>
                <div class="col-2">
                <label class="col-sm-0 col-form label"><strong>Sala:</strong></label>
                    <select class="form-select" name="sala">
                        <option value="Sala 01" {{ $sessao->sala == "Sala 01" ? "selected='selected'" : ""}}>Sala 01</option>
                        <option value="Sala 02" {{ $sessao->sala == "Sala 02" ? "selected='selected'" : ""}}>Sala 02</option>
                        <option value="Sala 03" {{ $sessao->sala == "Sala 03" ? "selected='selected'" : ""}}>Sala 03</option>
                    </select>
                </div>
            </div>
            </div>
            <br><br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/sessao/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

    
@endsection