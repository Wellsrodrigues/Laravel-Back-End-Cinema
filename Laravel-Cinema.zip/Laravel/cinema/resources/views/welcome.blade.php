@extends('layout.main')

@section('title', 'Cinetrix')

@section('content')

    <img width="100%" src="/img/home.png" alt="">

@endsection