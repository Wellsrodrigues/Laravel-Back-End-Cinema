@extends('layout.main')

@section('title', 'Ingressos')

@section('content')

   
    <br><br>
    <h2>Cadastrar Ingresso</h2>
    <br><br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/ingresso">
        @csrf
        <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>CPF_Cliente:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cpfCliente" placeholder="123.456.789-00" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Valor Unitário:</strong></label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="preco" placeholder="Ex: 20,00" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Tipo:</strong></label>
                    <select class="form-select" name="tipo">
                        <option disabled selected value=""></option>
                        <option value="Normal">Normal</option>
                        <option value="Meia Entrada">Meia Entrada</option>
                    </select>
                </div>
            </div>
            
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Qtd:</strong></label>
                    <div class="col-sm-11">
                        <input type="number" class="form-control" name="qtd" placeholder="Ex: 5" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Poltrona:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="poltrona" placeholder="Ex: 10-11-12" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                    <label class="col-sm-0 col-form label"><strong>Sessão:</strong></label>
                    <select class="form-select" name="sessaos_id">
                    <option disabled selected value=""></option>
                        @foreach( $sessao as $session)
                                <option value="{{$session->id}}">{{$session->id}}</option>
                        @endforeach
                     </select>
                </div>
            </div>
            <br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" name="enviar" class="btn btn-success" value="Finalizar Venda">
                    <a href="/ingresso/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

@endsection