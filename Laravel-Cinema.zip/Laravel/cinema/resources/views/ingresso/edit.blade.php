@extends('layout.main')

@section('title', 'Ingressos')

@section('content')

   
    <br><br>
    <h2>Atualizar dados do Ingresso</h2>
    <br><br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/ingresso/update/{{ $ingresso->id }}">
        @csrf
        @method('PUT')
        <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>CPF_Cliente:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cpfCliente" value="{{ $ingresso->cpfCliente }}" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Valor Unitário:</strong></label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="preco" value="{{ $ingresso->preco }}" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Tipo:</strong></label>
                    <select class="form-select" name="tipo">
                        <option value="Normal" {{ $ingresso->tipo == "Normal" ? "selected='selected'" : ""}}>Normal</option>
                        <option value="Meia Entrada" {{ $ingresso->tipo == "Meia Entrada" ? "selected='selected'" : ""}}>Meia Entrada</option>
                    </select>
                </div>
            </div>
            
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Qtd:</strong></label>
                    <div class="col-sm-11">
                        <input type="number" class="form-control" name="qtd" value="{{ $ingresso->qtd }}" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Poltrona:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="poltrona" value="{{ $ingresso->poltrona }}" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                    <label class="col-sm-0 col-form label"><strong>Sessão:</strong></label>

                    <select class="form-select" name="sessaos_id">
                        <option value="{{ $ingresso->sessaos_id }}">{{ $ingresso->sessaos_id }}</option>
                     </select>
                </div>
            </div>
            <br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/ingresso/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

@endsection
