@extends('layout.main')

@section('title', 'Ingressos')

@section('content')

    <div class="container">
        <br>
        <h2>Lista de Vendas Ingressos</h2>
        <a class="btn btn-primary" href="/ingresso/create" role="button">Nova Venda</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>CPF_Cliente</th>
                    <th>Tipo</th>
                    <th>Preço</th>
                    <th>Qtde</th>
                    <th>Poltrona</th>
                    <th>Sessão</th>
                    <th>Total</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
            @foreach($ingresso as $passe)
            <tr>
                <td>{{ $passe->id }}</td>
                <td>{{ $passe->cpfCliente }}</td>
                <td>{{ $passe->tipo }}</td>
                <td>R$ {{ $passe->preco }},00</td>
                <td>{{ $passe->qtd }}</td>
                <td>N° {{ $passe->poltrona }}</td>
                <td>Id {{ $passe->sessaos_id }}</td>
                <td>R$ {{ $passe->total }},00</td>
                <td>
                    <a href="#" class="btn btn-warning btn-sm"><i class="fa-solid fa-print"></i></a>
                    <a href="/ingresso/edit/{{ $passe->id }}" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <form action="/ingresso/{{ $passe->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                    </form>
                </td>
            </tr>
            @endforeach
            </tbody>
        </table>
    </div>

@endsection