@extends('layout.main')

@section('title', 'Relatório')

@section('content')

    <div class="container">
        <br><br><br>
        <h2>Relatório Financeiro</h2>
        <br><br>
        <a class="btn btn-primary" href="#" role="button">Enviar Relatório</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Data Relatório</th>
                    <th>Qtd_Ingressos</th>
                    <th>Meia Entrada</th>
                    <th>Normal</th>
                    <th>Receita Bruta</th>
                </tr>
            </thead>
            <tbody>

            <?php
               $qtd = 0;
               $meia = 0;
               $normal = 0;
               $receita = 0;

               foreach($ingresso as $passe){
                    $qtd += $passe->qtd;
                    $receita += $passe->total;
                    
                    if($passe->tipo == "Normal"){
                        $normal += $passe->qtd;
                    }
                
                    if($passe->tipo == "Meia Entrada"){
                        $meia += $passe->qtd;
                    }
                }

            if($qtd == 0){
                echo "
                    <div class='container'>
                    <div class='row'>
                        <div class='span4'>
                            <div class='alert alert-warning' role='alert'>
                                Não há registros no Sistema!
                            </div>
                        </div>
                    </div>
                </div>
                ";
            }
            ?>
             <tr>
                <td>{{date('d/m/Y')}}</td>
                <td>{{$qtd}}</td>
                <td>{{$meia}}</td>
                <td>{{$normal}}</td>
                <td>R$ {{$receita}},00</td>
            </tr>
            </tbody>
        </table>
    </div>

    
    @endsection