
@extends('layout.main')

@section('title', 'Filmes')

@section('content')
    <br>
    <h2>Cadastrar Filme</h2>
    <br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/filme">
        @csrf
        <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Titulo:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="titulo"  id="titulo" maxlength="40" placeholder="Ex: Homem-Aranha" autocomplete="off">
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Duração:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="duracao" id="duracao" placeholder="Ex: 120 min" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-z col-form label"><strong>Ano:</strong></label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="ano" id="ano" placeholder="Ex: 2022" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Classificação:</strong></label>
                    <select class="form-select" name="classificacao">
                        <option disabled selected value=""></option>
                        <option value="Livre">Livre</option>
                        <option value="+10">+10</option>
                        <option value="+12">+12</option>
                        <option value="+14">+14</option>
                        <option value="+16">+16</option>
                        <option value="+18">+18</option>
                    </select>
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Gênero:</strong></label>
                    <div class="col-sm-11">
                        <input type="text" class="form-control" name="genero" id="genero" placeholder="Ex: Ação" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Diretor:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="diretor" id="diretor" placeholder="Ex: James Gun" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Áudio:</strong></label>
                    <select class="form-select" name="audio">
                        <option disabled selected value=""></option>
                        <option value="Dublado">Dublado</option>
                        <option value="Legendado">Legendado</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Banner:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="banner" id="banner" placeholder="Insira o link da imagem promocional" autocomplete="off">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Sinopse:</strong></label>
                <div class="col-sm-12">
                    <textarea class="form-control" name="sinopse" id="sinopse" cols="30" rows="5"></textarea>
                </div>
            </div>
            <br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" name="enviar" class="btn btn-success" value="Cadastrar">
                    <a href="/filme/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

    @endsection