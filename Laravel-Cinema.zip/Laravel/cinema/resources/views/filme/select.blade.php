@extends('layout.main')

@section('title', 'Filmes')

@section('content')

<div class="container">
        <br>
        <h2>Tabela de Filmes</h2>
        <a class="btn btn-primary" href="/filme/create" role="button">Novo Filme</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Duração</th>
                    <th>Classif.</th>
                    <th>Ano</th>
                    <th>Gênero</th>
                    <th>Diretor</th>
                    <th>Áudio</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
                @foreach($filme as $movie)
                    <tr>
                        <td>{{ $movie->id }}</td>
                        <td>{{ $movie->titulo }}</td>
                        <td>{{ $movie->duracao }}</td>
                        <td>{{ $movie->classificacao }}</td>
                        <td>{{ $movie->ano }}</td>
                        <td>{{ $movie->genero }}</td>
                        <td>{{ $movie->diretor }}</td>
                        <td>{{ $movie->audio }}</td>
                        <td>
                            <a href="/filme/more/{{ $movie->id }}" class="btn btn-info btn-sm"><i class="fa-sharp fa-solid fa-circle-info"></i></a>
                            <a href="/filme/edit/{{ $movie->id }}" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                            <form action="/filme/{{ $movie->id }}" method="POST">
                                @csrf
                                @method('DELETE')
                                <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

@endsection