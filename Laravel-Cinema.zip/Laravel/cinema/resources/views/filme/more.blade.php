@extends('layout.main')

@section('title', 'Filmes')

@section('content')

    <br>
    <div class="backButton">
        <a href="/filme/select"><i class="fa-solid fa-chevron-left"></i></a>
    </div>
    <h2>Informações sobre o Filme</h2>
    <br>
    <div class="BoxMaster">
        <div class="box1">
            <img src="{{ $filme->banner }}" alt="Arte Promocional">
        </div>
    
        <div class="box2">
            <table>
                <tr>
                    <td>
                        <h5>Titulo: {{ $filme->titulo }}</h5>
                        <h5>Duração: {{ $filme->duracao }}</h5>
                        <h5>Classificação: {{ $filme->classificacao }}</h5>
                        <h5>Gênero: {{ $filme->genero }}</h5>
                        <h5>Diretor: {{ $filme->diretor }}</h5>
                        <h5>Ano: {{ $filme->ano }}</h5>
                        <h5>Áudio: {{ $filme->audio }}</h5>
                        <div style="width: 500px; text-align: justify;">
                            <h5>
                                <p>
                                    Sinopse: {{ $filme->sinopse}}
                                </p>
                            </h5>
                        </div>
                    </td>
                </tr>
            </table>
        </div>   
    </div>

@endsection