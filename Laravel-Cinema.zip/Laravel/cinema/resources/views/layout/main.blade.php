
<!DOCTYPE html>
<html lang="pt-br"
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="Tf=edge">
    <meta name="viewport" content="width-device-width, initial-scale-1.0">

    <title>@yield('title')</title>

    <link rel="stylesheet" href="/css/styles.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://kit.fontawesome.com/456bbda4c6.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
</head>
<body>
   
    <header id="topo">  
            <div class="logo">
                    <img src="/img/logo.png" alt="Logo da Cinetrix">
            </div>
    </header>

    <nav id="menu">
    <div id="optionsMenu">
            <a href="/">Página Inicial</a>
            <a href="/filme/select">Filmes</a>
            <a href="/sessao/select">Sessões</a>
            <a href="/ingresso/select">Ingressos</a>
            <a href="/funcionario/select">Funcionários</a>
            <a href="/relatorio">Relatório Financeiro</a>
        </div>
    </nav>
    @if(session('msg') == "error")
    <br><br>
        <div class='container'>
            <div class='row'>
                <div class='span4'>
                    <div class='alert alert-warning' role='alert'>
                        <strong>Error: Campo vazio! Tente Novamente!</strong>
                    </div>
                </div>
            </div>
        </div>
    @endif

    @yield('content')
    
    <br>
    <div class="msgs">
    @if(session('msg') == "1")
        <div class='container'>
            <div class='row'>
                <div class='span4'>
                    <div class='alert alert-success' role='alert'>
                        <strong>Cadastrado com sucesso!</strong>
                    </div>
                </div>
            </div>
        </div>
        @endif
        @if(session('msg') == "2")
        <div class='container'>
            <div class='row'>
                <div class='span4'>
                    <div class='alert alert-primary' role='alert'>
                        <strong>Atualizado com sucesso!</strong>
                    </div>
                </div>
            </div>
        </div>
        @endif
        @if(session('msg') == "3")
        <div class='container'>
            <div class='row'>
                <div class='span4'>
                    <div class='alert alert-danger' role='alert'>
                        <strong>Deletado com sucesso!</strong>
                    </div>
                </div>
            </div>
        </div>
        @endif
    </div>

    <!-- <footer>Cinetrix &copy;Copyrigth 2022</footer> -->
</body>