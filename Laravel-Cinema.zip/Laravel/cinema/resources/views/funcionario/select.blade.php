@extends('layout.main')

@section('title', 'Funcionários')

@section('content')

    <div class="container">
        <br>
        <h2>Lista de Funcionários</h2>
        <a class="btn btn-primary" href="/funcionario/create" role="button">Novo Funcionário</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>Cargo</th>
                    <th>Salário</th>
                    <th>Endereço</th>
                    <th>Telefone</th>
                    <th>Cinema</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>

            @foreach($funcionario as $func)
            <tr>
                <td>{{ $func->id }}</td>
                <td>{{ $func->nome }}</td>
                <td>{{ $func->cpf }}</td>
                <td>{{ $func->cargo }}</td>
                <td>R$ {{ $func->salario }},00</td>
                <td>{{ $func->endereco }}</td>
                <td>{{ $func->telefone }}</td>
                <td>
                    @foreach($cinema as $cine)
                        @if($func->cinemas_id == $cine->id)
                            {{ $cine->nome }} 
                        @endif
                    @endforeach
                </td>
                <td>
                    <a href="/funcionario/edit/{{ $func->id }}" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <form action="/funcionario/{{ $func->id }}" method="POST">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                    </form>
                </td>
            </tr>
            @endforeach
            </tbody>
        </table>
    </div>

@endsection