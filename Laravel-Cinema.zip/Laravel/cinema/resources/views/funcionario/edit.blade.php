@extends('layout.main')

@section('title', 'Funcionários')

@section('content')

<br>
    <h2>Atualizar dados do Filme</h2>
    <br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/funcionario/update/{{ $funcionario->id }}">
        @csrf
            @method('PUT')
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Nome:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="nome" value="{{ $funcionario->nome }}" maxlength="40" autocomplete="off">
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>CPF:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cpf" value="{{ $funcionario->cpf }}"  autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Cargo:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cargo"  value="{{ $funcionario->cargo }}"  autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Salário:</strong></label>
                    <div class="col-sm-12">
                        <input type="number" class="form-control" name="salario"  value="{{ $funcionario->salario }}"  autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Endereço:</strong></label>
                    <div class="col-sm-11">
                        <input type="text" class="form-control" name="endereco"  value="{{ $funcionario->endereco }}"  autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Telefone:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="telefone"  value="{{ $funcionario->telefone }}"  autocomplete="off">
                    </div>
                </div>
                <div class="col-5">
                    <label class="col-sm-0 col-form label"><strong>Cinema:</strong></label>
                    <select class="form-select" name="cinemas_id">
                        @foreach( $cinema as $cine)
                            <option value="{{$cine->id}}">{{$cine->nome}}</option>
                        @endforeach
                    </select>

                </div>
            </div>
            <br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/funcionario/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

    @endsection