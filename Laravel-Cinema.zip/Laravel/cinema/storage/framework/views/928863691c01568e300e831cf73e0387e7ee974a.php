

<?php $__env->startSection('title', 'Ingressos'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <br>
        <h2>Lista de Vendas Ingressos</h2>
        <a class="btn btn-primary" href="/ingresso/create" role="button">Nova Venda</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>CPF_Cliente</th>
                    <th>Tipo</th>
                    <th>Preço</th>
                    <th>Qtde</th>
                    <th>Poltrona</th>
                    <th>Sessão</th>
                    <th>Total</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $ingresso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($passe->id); ?></td>
                <td><?php echo e($passe->cpfCliente); ?></td>
                <td><?php echo e($passe->tipo); ?></td>
                <td>R$ <?php echo e($passe->preco); ?>,00</td>
                <td><?php echo e($passe->qtd); ?></td>
                <td>N° <?php echo e($passe->poltrona); ?></td>
                <td>Id <?php echo e($passe->sessaos_id); ?></td>
                <td>R$ <?php echo e($passe->total); ?>,00</td>
                <td>
                    <a href="#" class="btn btn-warning btn-sm"><i class="fa-solid fa-print"></i></a>
                    <a href="/ingresso/edit/<?php echo e($passe->id); ?>" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <form action="/ingresso/<?php echo e($passe->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/ingresso/select.blade.php ENDPATH**/ ?>