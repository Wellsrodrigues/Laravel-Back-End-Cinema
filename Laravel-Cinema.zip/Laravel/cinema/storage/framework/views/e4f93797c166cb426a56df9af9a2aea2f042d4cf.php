

<?php $__env->startSection('title', 'Ingressos'); ?>

<?php $__env->startSection('content'); ?>

   
    <br><br>
    <h2>Atualizar dados do Ingresso</h2>
    <br><br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/ingresso/update/<?php echo e($ingresso->id); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>CPF_Cliente:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cpfCliente" value="<?php echo e($ingresso->cpfCliente); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Valor Unitário:</strong></label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="preco" value="<?php echo e($ingresso->preco); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Tipo:</strong></label>
                    <select class="form-select" name="tipo">
                        <option value="Normal" <?php echo e($ingresso->tipo == "Normal" ? "selected='selected'" : ""); ?>>Normal</option>
                        <option value="Meia Entrada" <?php echo e($ingresso->tipo == "Meia Entrada" ? "selected='selected'" : ""); ?>>Meia Entrada</option>
                    </select>
                </div>
            </div>
            
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Qtd:</strong></label>
                    <div class="col-sm-11">
                        <input type="number" class="form-control" name="qtd" value="<?php echo e($ingresso->qtd); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Poltrona:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="poltrona" value="<?php echo e($ingresso->poltrona); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                    <label class="col-sm-0 col-form label"><strong>Sessão:</strong></label>

                    <select class="form-select" name="sessaos_id">
                        <option value="<?php echo e($ingresso->sessaos_id); ?>"><?php echo e($ingresso->sessaos_id); ?></option>
                     </select>
                </div>
            </div>
            <br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/ingresso/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/ingresso/edit.blade.php ENDPATH**/ ?>