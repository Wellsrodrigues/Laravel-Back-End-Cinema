

<?php $__env->startSection('title', 'Filmes'); ?>

<?php $__env->startSection('content'); ?>

    <br>
    <div class="backButton">
        <a href="/filme/select"><i class="fa-solid fa-chevron-left"></i></a>
    </div>
    <h2>Informações sobre o Filme</h2>
    <br>
    <div class="BoxMaster">
        <div class="box1">
            <img src="<?php echo e($filme->banner); ?>" alt="Arte Promocional">
        </div>
    
        <div class="box2">
            <table>
                <tr>
                    <td>
                        <h5>Titulo: <?php echo e($filme->titulo); ?></h5>
                        <h5>Duração: <?php echo e($filme->duracao); ?></h5>
                        <h5>Classificação: <?php echo e($filme->classificacao); ?></h5>
                        <h5>Gênero: <?php echo e($filme->genero); ?></h5>
                        <h5>Diretor: <?php echo e($filme->diretor); ?></h5>
                        <h5>Ano: <?php echo e($filme->ano); ?></h5>
                        <h5>Áudio: <?php echo e($filme->audio); ?></h5>
                        <div style="width: 500px; text-align: justify;">
                            <h5>
                                <p>
                                    Sinopse: <?php echo e($filme->sinopse); ?>

                                </p>
                            </h5>
                        </div>
                    </td>
                </tr>
            </table>
        </div>   
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/filme/more.blade.php ENDPATH**/ ?>