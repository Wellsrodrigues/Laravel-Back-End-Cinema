

<?php $__env->startSection('title', 'Relatório'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <br><br><br>
        <h2>Relatório Financeiro</h2>
        <br><br>
        <a class="btn btn-primary" href="#" role="button">Enviar Relatório</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Data Relatório</th>
                    <th>Qtd_Ingressos</th>
                    <th>Meia Entrada</th>
                    <th>Normal</th>
                    <th>Receita Bruta</th>
                </tr>
            </thead>
            <tbody>

            <?php
               $qtd = 0;
               $meia = 0;
               $normal = 0;
               $receita = 0;

               foreach($ingresso as $passe){
                    $qtd += $passe->qtd;
                    $receita += $passe->total;
                    
                    if($passe->tipo == "Normal"){
                        $normal += $passe->qtd;
                    }
                
                    if($passe->tipo == "Meia Entrada"){
                        $meia += $passe->qtd;
                    }
                }

            if($qtd == 0){
                echo "
                    <div class='container'>
                    <div class='row'>
                        <div class='span4'>
                            <div class='alert alert-warning' role='alert'>
                                Não há registros no Sistema!
                            </div>
                        </div>
                    </div>
                </div>
                ";
            }
            ?>
             <tr>
                <td><?php echo e(date('d/m/Y')); ?></td>
                <td><?php echo e($qtd); ?></td>
                <td><?php echo e($meia); ?></td>
                <td><?php echo e($normal); ?></td>
                <td>R$ <?php echo e($receita); ?>,00</td>
            </tr>
            </tbody>
        </table>
    </div>

    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/ingresso/relatorio.blade.php ENDPATH**/ ?>