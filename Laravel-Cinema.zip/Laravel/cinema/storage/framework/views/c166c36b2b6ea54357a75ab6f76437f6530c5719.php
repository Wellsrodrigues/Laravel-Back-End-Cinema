

<?php $__env->startSection('title', 'Filmes'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
        <br>
        <h2>Tabela de Filmes</h2>
        <a class="btn btn-primary" href="../view/cadastrar-filme.php" role="button">Novo Filme</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Duração</th>
                    <th>Classif.</th>
                    <th>Ano</th>
                    <th>Gênero</th>
                    <th>Diretor</th>
                    <th>Áudio</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
            <?php
                // require_once '../classes/autoload.inc.php';

                // $filme = new FilmeDAO();
                // $lista = $filme->listar();

                foreach ($lista AS $key => $value) {
            ?>
            <tr>
                <td><?php echo $value['idFilme']; ?></td>
                <td><?php echo $value['Titulo']; ?></td>
                <td><?php echo $value['Duração']; ?></td>
                <td><?php echo $value['Classificação']; ?></td>
                <td><?php echo $value['Ano']; ?></td>
                <td><?php echo $value['Genero']; ?></td>
                <td><?php echo $value['Diretor']; ?></td>
                <td><?php echo $value['Audio']; ?></td>
                <td>
                    <a href="../view/info-filme.php?idFilme=<?php echo $value['idFilme']; ?>" class="btn btn-info btn-sm"><i class="fa-sharp fa-solid fa-circle-info"></i></a>
                    <a href="../view/editar-filme.php?idFilme=<?php echo $value['idFilme']; ?>" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <a href="../database/remover-filme.php?idFilme=<?php echo $value['idFilme']; ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
                </td>
            </tr>
            <?php
                }
            ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/listar-filmes.blade.php ENDPATH**/ ?>