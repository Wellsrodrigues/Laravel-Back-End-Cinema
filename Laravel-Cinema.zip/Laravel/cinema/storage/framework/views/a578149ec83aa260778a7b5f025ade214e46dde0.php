

<?php $__env->startSection('title', 'Sessão'); ?>

<?php $__env->startSection('content'); ?>
    <br><br>
    <h2>Atualizar dados da Sessão</h2>
    <br><br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/sessao/update/<?php echo e($sessao->id); ?>">
        <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
                <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Data:</strong></label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" value="<?php echo e($sessao->dataSessao); ?>" name="dataSessao" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Horário:</strong></label>
                    <div class="col-sm-10">
                        <input type="time" class="form-control" value="<?php echo e($sessao->horario); ?>" name="horario" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Tipo:</strong></label>
                    <select class="form-select" name="tipo">
                        <option value="2D" <?php echo e($sessao->tipo == "2D" ? "selected='selected'" : ""); ?>>2D</option>
                        <option value="3D" <?php echo e($sessao->tipo == "3D" ? "selected='selected'" : ""); ?>>3D</option>
                        <option value="IMAX" <?php echo e($sessao->tipo == "IMAX" ? "selected='selected'" : ""); ?>>IMAX</option>
                    </select>
                </div>
            </div>
            <div class="group1">
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Qtd Lugares:</strong></label>
                    <select class="form-select" name="qtdLugares">
                        <option value="30" <?php echo e($sessao->qtdLugares == "30" ? "selected='selected'" : ""); ?>>30 Assentos</option>
                        <option value="45" <?php echo e($sessao->qtdLugares == "45" ? "selected='selected'" : ""); ?>>45 Assentos</option>
                        <option value="60" <?php echo e($sessao->qtdLugares == "60" ? "selected='selected'" : ""); ?>>60 Assentos</option>
                        <option value="100" <?php echo e($sessao->qtdLugares == "100" ? "selected='selected'" : ""); ?>>100 Assentos</option>
                    </select>
                </div>
                <div class="col-5">
                    <label class="col-sm-0 col-form label"><strong>Filme:</strong></label>

                    <select class="form-select" name="filmes_id">
                        <?php $__currentLoopData = $filme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($sessao->filmes_id); ?>" <?php echo e($sessao->filmes_id == $cine->id ? "selected='selected'" : ""); ?> ><?php echo e($cine->titulo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>

                </div>
                <div class="col-2">
                <label class="col-sm-0 col-form label"><strong>Sala:</strong></label>
                    <select class="form-select" name="sala">
                        <option value="Sala 01" <?php echo e($sessao->sala == "Sala 01" ? "selected='selected'" : ""); ?>>Sala 01</option>
                        <option value="Sala 02" <?php echo e($sessao->sala == "Sala 02" ? "selected='selected'" : ""); ?>>Sala 02</option>
                        <option value="Sala 03" <?php echo e($sessao->sala == "Sala 03" ? "selected='selected'" : ""); ?>>Sala 03</option>
                    </select>
                </div>
            </div>
            </div>
            <br><br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/sessao/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/sessao/edit.blade.php ENDPATH**/ ?>