

<?php $__env->startSection('title', 'Filmes'); ?>

<?php $__env->startSection('content'); ?>

    <br>
    <h2>Atualizar dados do Filme</h2>
    <br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/filme/update/<?php echo e($filme->id); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Titulo:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="titulo"  id="titulo" maxlength="40" autocomplete="off" value="<?php echo e($filme->titulo); ?>">
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Duração:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="duracao" id="duracao" autocomplete="off" value="<?php echo e($filme->duracao); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-z col-form label"><strong>Ano:</strong></label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="ano" id="ano" placeholder="Ex: 2022" autocomplete="off" value="<?php echo e($filme->ano); ?>">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Classificação:</strong></label>
                    <select class="form-select" name="classificacao">
                        <option value="Livre" <?php echo e($filme->classificacao == "Livre" ? "selected='selected'" : ""); ?>>Livre</option>
                        <option value="+10" <?php echo e($filme->classificacao == "+10" ? "selected='selected'" : ""); ?>>+10</option>
                        <option value="+12" <?php echo e($filme->classificacao == "+12" ? "selected='selected'" : ""); ?>>+12</option>
                        <option value="+14" <?php echo e($filme->classificacao == "+14" ? "selected='selected'" : ""); ?>>+14</option>
                        <option value="+16" <?php echo e($filme->classificacao == "+16" ? "selected='selected'" : ""); ?>>+16</option>
                        <option value="+18" <?php echo e($filme->classificacao == "+18" ? "selected='selected'" : ""); ?>>+18</option>
                    </select>
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Gênero:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="genero" id="genero" value="<?php echo e($filme->genero); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Diretor:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="diretor" id="diretor" value="<?php echo e($filme->diretor); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Áudio:</strong></label>
                    <select class="form-select" name="audio">
                        <option value="Dublado" <?php echo e($filme->audio == "Dublado" ? "selected='selected'" : ""); ?>>Dublado</option>
                        <option value="Legendado" <?php echo e($filme->audio == "Legendado" ? "selected='selected'" : ""); ?>>Legendado</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Banner:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="banner" id="banner" value="<?php echo e($filme->banner); ?>" autocomplete="off">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Sinopse:</strong></label>
                <div class="col-sm-12">
                    <textarea class="form-control" name="sinopse" id="sinopse" cols="30" rows="5"><?php echo e($filme->sinopse); ?></textarea>
                </div>
            </div>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/filme/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>
    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/filme/edit.blade.php ENDPATH**/ ?>