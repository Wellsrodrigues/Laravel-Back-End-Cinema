

<?php $__env->startSection('title', 'Filmes'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
        <br>
        <h2>Tabela de Filmes</h2>
        <a class="btn btn-primary" href="/filme/create" role="button">Novo Filme</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Titulo</th>
                    <th>Duração</th>
                    <th>Classif.</th>
                    <th>Ano</th>
                    <th>Gênero</th>
                    <th>Diretor</th>
                    <th>Áudio</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $filme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($movie->id); ?></td>
                        <td><?php echo e($movie->titulo); ?></td>
                        <td><?php echo e($movie->duracao); ?></td>
                        <td><?php echo e($movie->classificacao); ?></td>
                        <td><?php echo e($movie->ano); ?></td>
                        <td><?php echo e($movie->genero); ?></td>
                        <td><?php echo e($movie->diretor); ?></td>
                        <td><?php echo e($movie->audio); ?></td>
                        <td>
                            <a href="/filme/more/<?php echo e($movie->id); ?>" class="btn btn-info btn-sm"><i class="fa-sharp fa-solid fa-circle-info"></i></a>
                            <a href="/filme/edit/<?php echo e($movie->id); ?>" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                            <form action="/filme/<?php echo e($movie->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/filme/select.blade.php ENDPATH**/ ?>