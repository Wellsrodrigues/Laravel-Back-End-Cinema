

<?php $__env->startSection('title', 'Funcionários'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <br>
        <h2>Lista de Funcionários</h2>
        <a class="btn btn-primary" href="/funcionario/create" role="button">Novo Funcionário</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Nome</th>
                    <th>CPF</th>
                    <th>Cargo</th>
                    <th>Salário</th>
                    <th>Endereço</th>
                    <th>Telefone</th>
                    <th>Cinema</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>

            <?php $__currentLoopData = $funcionario; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $func): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($func->id); ?></td>
                <td><?php echo e($func->nome); ?></td>
                <td><?php echo e($func->cpf); ?></td>
                <td><?php echo e($func->cargo); ?></td>
                <td>R$ <?php echo e($func->salario); ?>,00</td>
                <td><?php echo e($func->endereco); ?></td>
                <td><?php echo e($func->telefone); ?></td>
                <td>
                    <?php $__currentLoopData = $cinema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($func->cinemas_id == $cine->id): ?>
                            <?php echo e($cine->nome); ?> 
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <a href="/funcionario/edit/<?php echo e($func->id); ?>" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <form action="/funcionario/<?php echo e($func->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/funcionario/select.blade.php ENDPATH**/ ?>