

<?php $__env->startSection('title', 'Filmes'); ?>

<?php $__env->startSection('content'); ?>

    <br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="">
            <input type="hidden" name="idFilme" id="idFilme" value="<?php echo e($filme->id); ?>">
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Titulo:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="titulo"  id="titulo" maxlength="40" autocomplete="off" value="<?php echo e($filme->titulo); ?>">
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Duração:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="duração" id="duração" autocomplete="off" value="<?php echo e($filme->duracao); ?>">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-z col-form label"><strong>Ano:</strong></label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control" name="ano" id="ano" placeholder="Ex: 2022" autocomplete="off" value="<?php echo e($filme->ano); ?>">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Classificação:</strong></label>
                    <select class="form-select" name="classificação">
                    <option disable selected value=""><?php echo e($filme->classificacao); ?></option>
                        <option value="Livre">Livre</option>
                        <option value="+10">+10</option>
                        <option value="+12">+12</option>
                        <option value="+14">+14</option>
                        <option value="+16">+16</option>
                        <option value="+18">+18</option>
                    </select>
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Gênero:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="genero" id="genero" value="<?php echo e($filme->genero); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Diretor:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="diretor" id="diretor" value="<?php echo e($filme->diretor); ?>" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Áudio:</strong></label>
                    <select class="form-select" name="audio">
                    <option disable selected value=""><?php echo e($filme->audio); ?></option>
                        <option value="Dublado">Dublado</option>
                        <option value="Legendado">Legendado</option>
                    </select>
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Banner:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="banner" id="banner" value="<?php echo e($filme->banner); ?>" autocomplete="off">
                </div>
            </div>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Sinopse:</strong></label>
                <div class="col-sm-12">
                    <textarea class="form-control" name="sinopse" id="sinopse" cols="30" rows="5"><?php echo e($filme->sinopse); ?></textarea>
                </div>
            </div>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" name="enviar" class="btn btn-success" value="Atualizar">
                    <a href="/filme/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

    
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/filme/update.blade.php ENDPATH**/ ?>