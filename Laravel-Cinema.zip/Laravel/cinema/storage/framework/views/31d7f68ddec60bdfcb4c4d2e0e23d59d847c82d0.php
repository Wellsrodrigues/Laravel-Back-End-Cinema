

<?php $__env->startSection('title', 'Funcionários'); ?>

<?php $__env->startSection('content'); ?>

    <br>
    <h2>Cadastrar Funcionário</h2>
    <br>
        <div class="col d-flex justify-content-center">
            <form class="formulario" method="post" action="/funcionario">
            <?php echo csrf_field(); ?>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Nome:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="nome"  maxlength="40" placeholder="Ex: José Paulo Costa" autocomplete="off">
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>CPF:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cpf" placeholder="123.456.789-00" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Cargo:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cargo" placeholder="Ex: Atendente" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Salário:</strong></label>
                    <div class="col-sm-12">
                        <input type="number" class="form-control" name="salario" placeholder="Ex: 1,200" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Endereço:</strong></label>
                    <div class="col-sm-11">
                        <input type="text" class="form-control" name="endereco" placeholder="Ex: Vila Paraiso, Q12, N 45" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Telefone:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="telefone" placeholder="Ex: (99) 98888-8888" autocomplete="off">
                    </div>
                </div>
                <div class="col-5">
                    <label class="col-sm-0 col-form label"><strong>Cinema:</strong></label>
                    <select class="form-select" name="cinemas_id">
                        <option disabled selected value=""></option>
                        <?php $__currentLoopData = $cinema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cine->id); ?>"><?php echo e($cine->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" name="enviar" class="btn btn-success" value="Cadastrar">
                    <a href="/funcionario/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/funcionario/create.blade.php ENDPATH**/ ?>