

<?php $__env->startSection('title', 'Sessão'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
        <br>
        <h2>Sessões de Filmes</h2>
        <a class="btn btn-primary" href="/sessao/create" role="button">Nova Sessão</a>
        <br><br>
        <table class="table">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Data</th>
                    <th>Horário</th>
                    <th>Tipo</th>
                    <th>Sala</th>
                    <th>Assentos</th>
                    <th>Filme</th>
                    <th>Operações</th>
                </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $sessao; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $session): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($session->id); ?></td>
                <td><?php echo e(date('d/m/Y', strtotime ($session->dataSessao))); ?></td>
                <td><?php echo e($session->horario); ?></td>
                <td><?php echo e($session->tipo); ?></td>
                <td><?php echo e($session->sala); ?></td>
                <td><?php echo e($session->qtdLugares); ?></td>
                <td>
                    <?php $__currentLoopData = $filme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($session->filmes_id == $movie->id): ?>
                            <?php echo e($movie->titulo); ?> 
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <a href="/sessao/edit/<?php echo e($session->id); ?>" class="btn btn-success btn-sm"><i class="fa-sharp fa-solid fa-pen"></i></a>
                    <form action="/sessao/<?php echo e($session->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm"> <i class="fa-solid fa-trash"> </i></button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/sessao/select.blade.php ENDPATH**/ ?>