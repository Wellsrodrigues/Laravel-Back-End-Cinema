<?php $__env->startSection('title', 'Cinetrix'); ?>

<?php $__env->startSection('content'); ?>

    <img width="100%" src="/img/home.png" alt="">

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/welcome.blade.php ENDPATH**/ ?>