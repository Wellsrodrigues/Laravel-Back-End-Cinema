

<?php $__env->startSection('title', 'Funcionários'); ?>

<?php $__env->startSection('content'); ?>

<br>
    <h2>Atualizar dados do Filme</h2>
    <br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/funcionario/update/<?php echo e($funcionario->id); ?>">
        <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row mb-3">
                <label class="col-sm-0 col-form label"><strong>Nome:</strong></label>
                <div class="col-sm-12">
                    <input type="text" class="form-control" name="nome" value="<?php echo e($funcionario->nome); ?>" maxlength="40" autocomplete="off">
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>CPF:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cpf" value="<?php echo e($funcionario->cpf); ?>"  autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Cargo:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="cargo"  value="<?php echo e($funcionario->cargo); ?>"  autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Salário:</strong></label>
                    <div class="col-sm-12">
                        <input type="number" class="form-control" name="salario"  value="<?php echo e($funcionario->salario); ?>"  autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Endereço:</strong></label>
                    <div class="col-sm-11">
                        <input type="text" class="form-control" name="endereco"  value="<?php echo e($funcionario->endereco); ?>"  autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Telefone:</strong></label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="telefone"  value="<?php echo e($funcionario->telefone); ?>"  autocomplete="off">
                    </div>
                </div>
                <div class="col-5">
                    <label class="col-sm-0 col-form label"><strong>Cinema:</strong></label>
                    <select class="form-select" name="cinemas_id">
                        <?php $__currentLoopData = $cinema; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cine): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cine->id); ?>"><?php echo e($cine->nome); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
            </div>
            <br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" class="btn btn-success" value="Atualizar">
                    <a href="/funcionario/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/funcionario/edit.blade.php ENDPATH**/ ?>