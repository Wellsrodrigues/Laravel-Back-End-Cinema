

<?php $__env->startSection('title', 'Sessão'); ?>

<?php $__env->startSection('content'); ?>

<br><br>
    <h2>Criar Sessão</h2>
    <br><br>
    <div class="col d-flex justify-content-center">
        <form class="formulario" method="post" action="/sessao">
        <?php echo csrf_field(); ?>
            <div class="group1">
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Data:</strong></label>
                    <div class="col-sm-10">
                        <input type="date" class="form-control" name="dataSessao" autocomplete="off">
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-0 col-form label"><strong>Horário:</strong></label>
                    <div class="col-sm-10">
                        <input type="time" class="form-control" name="horario" autocomplete="off">
                    </div>
                </div>
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Tipo:</strong></label>
                    <select class="form-select" name="tipo">
                        <option disabled selected value=""></option>
                        <option value="2D">2D</option>
                        <option value="3D">3D</option>
                        <option value="IMAX">IMAX</option>
                    </select>
                </div>
            </div>
            <div class="group1">
                <div class="col-3">
                <label class="col-sm-0 col-form label"><strong>Qtd Lugares:</strong></label>
                    <select class="form-select" name="qtdLugares">
                        <option disabled selected value=""></option>
                        <option value="30">30 Assentos</option>
                        <option value="45">45 Assentos</option>
                        <option value="60">60 Assentos</option>
                        <option value="100">100 Assentos</option>
                    </select>
                </div>
                <div class="col-5">
                    <label class="col-sm-0 col-form label"><strong>Filme:</strong></label>
                        <select class="form-select" name="filmes_id">
                            <option disabled selected value=""></option>
                        <?php $__currentLoopData = $filme; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($movie->id); ?>"><?php echo e($movie->titulo); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                </div>
                <div class="col-2">
                <label class="col-sm-0 col-form label"><strong>Sala:</strong></label>
                    <select class="form-select" name="sala">
                    <option disabled selected value=""></option>
                        <option value="Sala 01">Sala 01</option>
                        <option value="Sala 02">Sala 02</option>
                        <option value="Sala 03">Sala 03</option>
                    </select>
                </div>
            </div>
            <br><br><br>
            <div class="col d-flex justify-content-center">
                <div class="buttons">
                    <input type="submit" name="enviar" class="btn btn-success" value="Cadastrar">
                    <a href="/sessao/select" type="button" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </form>
    </div>
    <div class="space"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Wellison\.vscode\Project\Laravel\cinema\resources\views/sessao/create.blade.php ENDPATH**/ ?>